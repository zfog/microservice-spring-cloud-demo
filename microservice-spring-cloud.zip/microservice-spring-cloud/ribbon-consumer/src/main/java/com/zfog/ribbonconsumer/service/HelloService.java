package com.zfog.ribbonconsumer.service;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class HelloService {

    @Autowired
    private RestTemplate restTemplate;
    private String url = "http://PROVIDER-USER/hello";

    /**
     * 使用@HystrixCommand注解创建HystrixCommand实现，并通过fallbackMethod指定服务降级的实现
     * @return
     */
    @HystrixCommand(fallbackMethod = "helloFallback")
    public String helloService() {
        System.out.println("helloService");
        return restTemplate.getForObject(url, String.class);
    }

    public String helloFallback() {
        return "error";
    }
}
